import UIKit

var mypun1 = "I feel like everyone here is a clock"

var mypun2 = "why?"

var mypun3 = "because nobody got time for me"

var mypun4 = "yeah I can see why"

print(mypun1)
print (mypun2)
print(mypun3)
print(mypun4)
